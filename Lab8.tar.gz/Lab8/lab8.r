library(gapminder)
library(dplyr)
library(tidyverse)
library(ggplot2)
library(psych)

library(ctv)
twoCountry <- read.csv(file = "/home/o/ocampod/fall2017/cs390-ochampoo/Data-Analytics/Lab8/lab8Data.csv", header=TRUE, sep= ",")
View(twoCountry)
twoCountry[1,]

###### Question 1 ######The decline in marriage rates,

WifeBeater <- filter(
  twoCountry ,
  Indicator.Name ==  "Women who believe a husband is justified in beating his wife (any of five reasons) (%)"
  
)

View(WifeBeater)


LiteracyGender <- filter(
  twoCountry,
  Indicator.Name ==  "Literacy rate, adult female (% of females ages 15 and above)" | Indicator.Name ==  "Literacy rate, adult male (% of males ages 15 and above)
")

View(LiteracyGender)

SavedForEducation <- filter(
  twoCountry ,
  Indicator.Name ==  "Saved for education or school fees, female (% age 15+) [w2]" | Indicator.Name ==  "Literacy rate, adult male (% of males ages 15 and above)
")

View(SavedForEducation)

laborforceGender <- filter(
  twoCountry ,
Indicator.Name ==  "Labor force, female")

View(laborforceGender)

####################################### End Of Question 1 #################

###### Question 2 ############# The narrowing gender wage gap,
twoCountry <- filter(
  twoCountry ,
  Indicator.Name ==  "Wage and salaried workers, female (% of female employment)" | Indicator.Name ==  "Wage and salaried workers, male (% of male employment)"
)

twoCountry <- filter(
  twoCountry ,
  Indicator.Name ==  "Children in employment, female (% of female children ages 7-14)" | Indicator.Name ==  "Children in employment, male (% of male children ages 7-14)
"
)

twoCountry <- filter(
  twoCountry ,
  Indicator.Name ==  "Cost of business start-up procedures, female (% of GNI per capita)
" | Indicator.Name ==  "Cost of business start-up procedures, male (% of GNI per capita)"
)

twoCountry <- filter(
  twoCountry ,
  Indicator.Name ==  "Expected years of schooling, female" | Indicator.Name ==  "Expected years of schooling, male")



####################### end of  Question 2  #############



### Question 3 ###### preference (or cultural) shift towards market work, and



##### End of question 3 ##########
#### Question 4 ### The change in womens bargaining power within the household.



twoCountry <- filter(
  twoCountry ,
  Indicator.Name ==  "Women who do not own a house (% of women age 15-49)")


twoCountry <- filter(
  twoCountry ,
  Indicator.Name ==  "Women who own a house alone (% of women age 15-49)"
)
twoCountry <- filter(
  twoCountry ,
  Indicator.Name ==  "Women who own a house jointly (% of women age 15-49)"
)

twoCountry <- filter(
  twoCountry ,
  Indicator.Name ==  "Decision maker about a woman's own health care: mainly husband (% of women age 15-49)
" | Indicator.Name ==  "Decision maker about a woman's own health care: mainly wife (% of women age 15-49)
"
)

twoCountry <- filter(
  twoCountry ,
  Indicator.Name ==  "Decision maker about major household purchases: mainly husband (% of women age 15-49)

" | Indicator.Name ==  "Decision maker about major household purchases: mainly wife (% of women age 15-49)
"
)





###########End of question 4####


### Intresting Data 

womenHiv <- filter(
  twoCountry,
  Indicator.Name ==  "Women's share of population ages 15+ living with HIV (%)"
)


twoCountry <- filter(
  twoCountry ,
  Indicator.Name ==  "Employment to population ratio, 15+, female (%) (modeled ILO estimate)
" | Indicator.Name ==  "Employment to population ratio, 15+, male (%) (modeled ILO estimate)
"
)









twoCountry <- filter(
  twoCountry ,
  Indicator.Name ==  "Women who were first married by age 18 (% of women ages 20-24)"
)



View(twoCountry)
write.csv(twoCountry,"/home/o/ocampod/fall2017/cs390-ochampoo/Data-Analytics/Lab8/lab8data.csv")
