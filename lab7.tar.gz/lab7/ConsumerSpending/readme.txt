  a Value is less than or equal to 0.05.                                             
  b Value is less than or equal to 0.5.                                              
  c Data are likely to have large sampling errors.                                   
  d No data reported.                                                                
                                                                                     
                                                                                     
                                                                                     
Source: Consumer Expenditure Survey, U.S. Bureau of Labor Statistics, September, 2011

